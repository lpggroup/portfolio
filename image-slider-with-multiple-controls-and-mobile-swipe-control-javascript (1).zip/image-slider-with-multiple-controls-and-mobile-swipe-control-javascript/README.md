# Image slider with multiple controls and mobile swipe control (Javascript)

A Pen created on CodePen.io. Original URL: [https://codepen.io/joso2018/pen/LYmxPRo](https://codepen.io/joso2018/pen/LYmxPRo).

